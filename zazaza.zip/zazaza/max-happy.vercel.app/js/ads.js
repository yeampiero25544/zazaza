// Ads terra Historia
var script = document.createElement('script');
script.type = 'text/javascript';
script.src = '//noisesperusemotel.com/6c/9c/ca/6c9cca2344310fc5890c46b7c2e6c2ca.js';

// Agregar el elemento <script> al final del body
document.body.appendChild(script);

